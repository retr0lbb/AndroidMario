package com.example.henrysapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        val alturaInput = findViewById<EditText>(R.id.altura1)
        val pesoInput = findViewById<EditText>(R.id.peso1)
        val resultado = findViewById<TextView>(R.id.resultado1)
        val triggerBtn = findViewById<Button>(R.id.button)


        triggerBtn.setOnClickListener {
            try {
                val altura = alturaInput.text.toString().toDouble()
                val peso = pesoInput.text.toString().toDouble()

                val imc = peso/(altura * altura)

                val resultOriginalText = resultado.text

                val formattedImc = "%.2f".format(imc)

                "$resultOriginalText $formattedImc".also { resultado.text = it }
            }catch (e: Exception){
                Toast.makeText(this, "Digite apenas valores validos", Toast.LENGTH_LONG).show()
            }
        }
    }
}